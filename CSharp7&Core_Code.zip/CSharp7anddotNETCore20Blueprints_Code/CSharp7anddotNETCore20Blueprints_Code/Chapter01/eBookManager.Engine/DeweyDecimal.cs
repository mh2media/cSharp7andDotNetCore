﻿namespace eBookManager.Engine
{
    public class DeweyDecimal
    {
        public string ComputerScience { get; set; } = "000";
        public string DataProcessing { get; set; } = "004";
        public string ComputerProgramming { get; set; } = "005";
    }
}
