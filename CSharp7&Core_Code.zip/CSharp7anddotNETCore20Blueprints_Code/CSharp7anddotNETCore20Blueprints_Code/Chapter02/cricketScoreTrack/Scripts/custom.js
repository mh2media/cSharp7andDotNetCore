﻿function openModal() {
    $('#playerModal').modal('show');
}

