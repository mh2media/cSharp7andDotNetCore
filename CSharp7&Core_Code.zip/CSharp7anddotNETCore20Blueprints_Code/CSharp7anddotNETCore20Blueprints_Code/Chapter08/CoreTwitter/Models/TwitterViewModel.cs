﻿using CoreTwitter.Classes;
using System.Collections.Generic;

namespace CoreTwitter.Models
{
    public class TwitterViewModel
    {
        public List<TweetItem> HomeTimelineTweets { get; set; }
    }
}
