﻿namespace CoreTwitter.Classes
{
    public class TweetItem
    {
        public string Url { get; set; }
    }
}
